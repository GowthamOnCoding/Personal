package com.cinebook.week1;

public class ChunkingDemo {
  public static void main(String[] args) {
    int N = 10_000_000;
    int CHUNK = 10_000;
    int[] a = new int[N];
    for (int i = 0; i < N; i++) a[i] = i;

    long sum = 0;
    for (int start = 0; start < N; start += CHUNK) {
      int end = Math.min(start + CHUNK, N);
      for (int i = start; i < end; i++) sum += a[i];
      // imagine flushing this batch here
    }
    System.out.println("Sum = " + sum);
  }
}
