package com.cinebook.week1;

import java.util.concurrent.*;

public class VirtualThreadsDemo {
  public static void main(String[] args) throws Exception {
    try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
      var futures = new java.util.ArrayList<Future<?>>();
      for (int i = 0; i < 5000; i++) {
        int id = i;
        futures.add(exec.submit(() -> {
          Thread.sleep(50); // pretend I/O
          if (id % 1000 == 0) System.out.println("Done: " + id);
          return null;
        }));
      }
      for (var f : futures) f.get();
      System.out.println("All done!");
    }
  }
}
