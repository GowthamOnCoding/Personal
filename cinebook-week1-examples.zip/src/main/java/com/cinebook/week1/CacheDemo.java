package com.cinebook.week1;

import java.util.Random;

public class CacheDemo {
  static final int N = 8_000_000; // keep safe for most laptops

  public static void main(String[] args) {
    int[] a = new int[N];
    for (int i = 0; i < N; i++) a[i] = i;

    int[] idx = new int[N];
    for (int i = 0; i < N; i++) idx[i] = i;
    // Fisher–Yates shuffle to avoid boxing overhead
    Random r = new Random(42);
    for (int i = N - 1; i > 0; i--) {
      int j = r.nextInt(i + 1);
      int tmp = idx[i]; idx[i] = idx[j]; idx[j] = tmp;
    }

    long t1 = System.currentTimeMillis();
    long sum1 = 0;
    for (int i = 0; i < N; i++) sum1 += a[i];       // linear
    long t2 = System.currentTimeMillis();

    long sum2 = 0;
    for (int i = 0; i < N; i++) sum2 += a[idx[i]];  // scattered
    long t3 = System.currentTimeMillis();

    System.out.printf("Linear: %d ms  |  Scattered: %d ms  (ignore sums: %d/%d)%n",
        (t2 - t1), (t3 - t2), sum1, sum2);
  }
}
