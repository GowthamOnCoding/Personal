package com.cinebook.week1;

public class BoxingDemo {
  public static void main(String[] args) {
    int N = 1_000_000;

    int[] p = new int[N];
    for (int i = 0; i < N; i++) p[i] = i;

    Integer[] b = new Integer[N];
    for (int i = 0; i < N; i++) b[i] = i;

    long t1 = System.currentTimeMillis();
    long sp = 0; for (int i = 0; i < N; i++) sp += p[i];
    long t2 = System.currentTimeMillis();

    long sb = 0; for (int i = 0; i < N; i++) sb += b[i]; // auto-unboxing overhead
    long t3 = System.currentTimeMillis();

    System.out.printf("Primitives: %d ms | Boxed: %d ms%n", (t2 - t1), (t3 - t2));
  }
}
