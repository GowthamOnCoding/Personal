package com.cinebook.week1;

import java.util.*;

public class ListShapeDemo {
  public static void main(String[] args) {
    int N = 500_000;

    List<Integer> arrayList = new ArrayList<>(N);
    for (int i = 0; i < N; i++) arrayList.add(i);

    List<Integer> linkedList = new LinkedList<>();
    for (int i = 0; i < N; i++) linkedList.add(i);

    long t1 = System.currentTimeMillis();
    long s1 = 0; for (int x : arrayList) s1 += x;
    long t2 = System.currentTimeMillis();

    long s2 = 0; for (int x : linkedList) s2 += x;
    long t3 = System.currentTimeMillis();

    System.out.printf("ArrayList: %d ms | LinkedList: %d ms%n", (t2 - t1), (t3 - t2));
  }
}
