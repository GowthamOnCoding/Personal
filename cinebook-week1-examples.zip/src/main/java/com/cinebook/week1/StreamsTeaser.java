package com.cinebook.week1;

import java.util.*;
import static java.util.Comparator.comparing;

record Movie(String title, String genre, int rating) {}

public class StreamsTeaser {
  public static void main(String[] args) {
    List<Movie> movies = List.of(
      new Movie("Inception","Sci‑Fi", 9),
      new Movie("Leo","Action", 8),
      new Movie("Avatar","Fantasy", 7)
    );
    var top = movies.stream()
      .filter(m -> m.rating() >= 8)
      .sorted(comparing(Movie::rating).reversed())
      .toList();
    System.out.println(top);
  }
}
