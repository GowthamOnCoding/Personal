package com.cinebook.week1;

public class GCDemo {
  static byte[] hold;
  public static void main(String[] args) {
    Runtime rt = Runtime.getRuntime();
    System.out.printf("Before: total=%d free=%d%n", rt.totalMemory(), rt.freeMemory());
    hold = new byte[50 * 1024 * 1024]; // 50 MB
    System.out.printf("After alloc: total=%d free=%d%n", rt.totalMemory(), rt.freeMemory());
    hold = null;
    System.gc();
    System.out.printf("After GC: total=%d free=%d%n", rt.totalMemory(), rt.freeMemory());
  }
}
