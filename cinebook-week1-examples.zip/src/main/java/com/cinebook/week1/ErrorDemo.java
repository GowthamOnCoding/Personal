package com.cinebook.week1;

public class ErrorDemo {
  public static void main(String[] args) {
    // This will throw NumberFormatException: For input string: "abc"
    int x = Integer.parseInt("abc");
    System.out.println(x);
  }
}
