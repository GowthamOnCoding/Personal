package com.cinebook.week1;

import java.util.Scanner;

public class MenuDemo {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int choice = -1;
    while (choice != 3) {
      System.out.println("\n🎬 Welcome to CineBook");
      System.out.println("1. View Movies");
      System.out.println("2. Book Ticket");
      System.out.println("3. Exit");
      System.out.print("Enter choice: ");
      if (!sc.hasNextInt()) { System.out.println("Please enter a number!"); sc.next(); continue; }
      choice = sc.nextInt();
      switch (choice) {
        case 1 -> System.out.println("Movies: Inception, Leo, Avatar");
        case 2 -> System.out.println("Booking... (coming soon)");
        case 3 -> System.out.println("Goodbye 👋");
        default -> System.out.println("Invalid choice, try again!");
      }
    }
  }
}
