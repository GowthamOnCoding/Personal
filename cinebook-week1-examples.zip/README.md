# CineBook — Week 1 Java Examples

Hands-on snippets for today's session. Import into **IntelliJ** (File → Open → select this folder) or run with **Gradle** or plain **javac/java**.

## Requirements
- **JDK 21** (needed for Virtual Threads demo). Other examples work on JDK 17+, but 21 recommended for consistency.
- Optional: **Gradle** (IntelliJ can use the included `build.gradle` directly).

## Run with Gradle (recommended)
In a terminal from this folder:
```bash
# Compile everything
./gradlew build   # if you have a wrapper; otherwise install gradle and run: gradle build

# Run a specific example (choose one)
gradle runMain
gradle runMenuDemo
gradle runCacheDemo
gradle runChunkingDemo
gradle runListShapeDemo
gradle runBoxingDemo
gradle runGCDemo
gradle runVirtualThreadsDemo   # requires JDK 21
gradle runStreamsTeaser
gradle runErrorDemo
```

> If you don't have a Gradle wrapper here, install Gradle or use IntelliJ's "Run Gradle Task".

## Run with plain javac/java
```bash
# Compile
javac -d out $(find src -name "*.java")

# Run (example)
java -cp out com.cinebook.week1.Main
```

## Notes
- **Cache & working set demos**: Try changing sizes to feel the difference.
- **Virtual Threads**: Requires JDK 21 (`java --version` to check).
- **GCDemo**: Try running with `-Xms64m -Xmx64m -Xlog:gc*` for GC logs.
