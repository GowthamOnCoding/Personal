package com.example.migrator;

public class EncryptPasswordTool {
    public static void main(String[] args) throws Exception {
        String username = "root";
        String password = "mypassword";

        System.out.println("Encrypted Username: " + CryptoUtil.encrypt(username));
        System.out.println("Encrypted Password: " + CryptoUtil.encrypt(password));
    }
}
