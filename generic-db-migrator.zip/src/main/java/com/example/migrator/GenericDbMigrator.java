package com.example.migrator;

import java.sql.*;
import java.util.*;

public class GenericDbMigrator {

    public static void main(String[] args) {
        if (args.length < 3) {
            System.err.println("Usage: java GenericDbMigrator <table_name> <filter_condition> <config_file_path>");
            System.exit(1);
        }

        String tableName = args[0];
        String filterCondition = args[1];
        String configPath = args[2];

        try {
            ConfigLoader config = new ConfigLoader(configPath);

            String srcUrl = config.getRaw("source.url");
            String srcUser = config.getDecrypted("source.user");
            String srcPass = config.getDecrypted("source.password");

            String destUrl = config.getRaw("dest.url");
            String destUser = config.getDecrypted("dest.user");
            String destPass = config.getDecrypted("dest.password");

            try (
                Connection sourceConn = DriverManager.getConnection(srcUrl, srcUser, srcPass);
                Connection destConn = DriverManager.getConnection(destUrl, destUser, destPass);
            ) {
                List<Map<String, Object>> rows = fetchFilteredRows(sourceConn, tableName, filterCondition);
                insertRows(destConn, tableName, rows);
                System.out.println("✅ Migration completed for table `" + tableName + "`.");
            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static List<Map<String, Object>> fetchFilteredRows(Connection conn, String tableName, String filter) throws SQLException {
        List<Map<String, Object>> resultList = new ArrayList<>();

        String query = "SELECT * FROM " + tableName + " WHERE " + filter;
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            ResultSetMetaData meta = rs.getMetaData();
            int columnCount = meta.getColumnCount();

            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.put(meta.getColumnName(i), rs.getObject(i));
                }
                resultList.add(row);
            }
        }

        return resultList;
    }

    private static void insertRows(Connection conn, String tableName, List<Map<String, Object>> rows) throws SQLException {
        if (rows.isEmpty()) {
            System.out.println("⚠️ No data found to insert.");
            return;
        }

        Map<String, Object> sampleRow = rows.get(0);
        String columnNames = String.join(", ", sampleRow.keySet());
        String placeholders = String.join(", ", Collections.nCopies(sampleRow.size(), "?"));
        String insertSQL = "INSERT INTO " + tableName + " (" + columnNames + ") VALUES (" + placeholders + ")";

        try (PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
            for (Map<String, Object> row : rows) {
                int index = 1;
                for (Object value : row.values()) {
                    pstmt.setObject(index++, value);
                }
                pstmt.addBatch();
            }
            pstmt.executeBatch();
        }
    }
}
