package com.example.migrator;

import java.io.FileInputStream;
import java.util.Properties;

public class ConfigLoader {
    private Properties props;

    public ConfigLoader(String filePath) throws Exception {
        props = new Properties();
        props.load(new FileInputStream(filePath));
    }

    public String getDecrypted(String key) throws Exception {
        return CryptoUtil.decrypt(props.getProperty(key));
    }

    public String getRaw(String key) {
        return props.getProperty(key);
    }
}
